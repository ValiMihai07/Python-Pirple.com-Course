
def compare( a , b , c):
    if( int(a) == int(b) or int(b)==int(c) or int(c)==int(a)):
        print("True")
    else:
        print("False")
        
        
compare( 5 , 6 , "5")