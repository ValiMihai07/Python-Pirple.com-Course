
def Genre():
    return "Jazz"

def Artist():
    return "Bruno Mars"

def Time():
    return 3.56

def HaveSucces():
    return True

genreVar = Genre() 
artistVar = Artist()
timeVar = Time()
haveSuccesVar = HaveSucces()


print(genreVar)
print(artistVar)
print(timeVar)
print(haveSuccesVar)