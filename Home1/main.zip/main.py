"""
Here we have my favorite song
and i describe it a little with
what i learned in the video
"""
artist = "Bruno Mars"
name_of_song = "Just the way you are"
time_of_song = 3.57
year_of_release = 2011
genre = "Jazz"
succes_or_not = True

# Here i print all the variables
print(artist)
print(name_of_song)
print(time_of_song)
print(year_of_release)
print(genre)
print(succes_or_not)